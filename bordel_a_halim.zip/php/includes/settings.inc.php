<?php   // 'settings.inc.php' ~ Useful settings for the whole system (classes, functions, etc)

/* ----- Database Configuration ----- */
define("DB_HOST", "localhost");
define("DB_PORT", "3306");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "bdd");
define("DB_CHARSET", "utf8");

/* ----- Database Tables Names ----- */
define("TABLE_TEST", "qcmaster_Test");
//define("TABLE_USER", "qcmaster_User");
//define("TABLE_QCM", "qcmaster_QCM");
//define("TABLE_QUESTION", "qcmaster_Question");

/* ----- Another Configuration ----- */
/*
    INSERT CONFIG
    CODE HERE
*/

// End of file ~ We don't close the PHP tag here, in order to avoid inserting invisible characters