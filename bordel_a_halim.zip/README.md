# QCMaster Project

## Files Organization

 * All CSS files must be under '/css/' folder
 * All Javascript files must be under '/js/' folder
 * All Images must be under '/img/' folder
 * All PHP Classes files must be under '/php/classes/' folder
 * All PHP Includes files must be under '/php/includes/' folder
 * All PHP Pages files must be under '/php/pages/' folder
 * All SQL Scripts (to generate the Database) must be under '/sql/' folder
 * ...
 
## Credits

Project for "Méthodologie de la production d'applications", realized by students at Lyon1 University in Bourg-en-Bresse

 * **TEAM**
 * **H**alim Azizi
 * **A**lec Montrade
 * **T**om-Brian Garcia
 * **E**nzo Contini
 * **D**yvia Fleury
 
## Status

This project is still in developement !
This page will be updated when we'll have stable releases.
